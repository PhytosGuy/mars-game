# Mars: Last Colony

A survival, exploration and colony-building game set on a NASA-science-inspired Mars, in the style of Astroneer and Slow Roads. It runs in the browser and is one self-contained `index.html` with no build step. Three.js loads from a CDN.

## Play locally
Open `index.html` in a browser, or serve the folder:

```bash
python -m http.server 8123
```

Then go to http://localhost:8123.

## Deploy for free

**Vercel**
1. Push this folder to a GitHub repository.
2. On vercel.com, choose **Add New → Project**, import the repo and keep the defaults (Framework preset: **Other**, no build command, output directory `.`).
3. Click **Deploy**. Vercel serves `index.html` as a static site.

If you'd rather not use GitHub, run `npx vercel` in this folder.

**Netlify or GitHub Pages** also work. Drag this folder onto app.netlify.com/drop, or turn on Pages for the repo.

## Controls
WASD: walk/drive · Hold left mouse (or Q): vacuum up materials · Right-drag: look around · Scroll: zoom · Shift: sprint · Space: jump/brake · E: board/exit rover · C: cruise control · F: scan/collect/clean/repair/airlock · B: build mode · X: recycle mode · R: rotate · Tab: colony & research · M: map · J: show/hide objectives · I: show/hide colony status · H: photo mode · N: music · Esc: pause

The orange arrow on the ground (and the ▼ on the compass) always points at your next task. Near the habitat, the coat-hanger button opens the wardrobe, where you can change suit colours, visor, backpack, extras and rover paint.

The game autosaves to browser storage every 30 seconds.

## Features
- **Caves:** scan a lava-tube skylight, then press F to climb down. Inside you can vacuum ore and ice and study crystals, and each cave has a major discovery at the end. Keep an eye on your oxygen.
- **City growth:** colonists arrive by ship once you have homes and supplies. The colony grows from Outpost to Settlement, Town, City and Metropolis, unlocking futuristic tech: Geodesic Domes, Arcology Towers, Atmosphere Processors, Fusion Reactors and a Spaceport.
- **Emergencies and secrets:** meteor strikes leave craters, can damage buildings and drop iron meteorites. Hidden meteorites also lie scattered across the land, and you only spot them up close.
- **Co-op (up to 4 players):** in a game, press Esc, choose **Invite friends** and share the 5-letter code. Friends use **Join a friend** on the title screen. The connection is peer-to-peer through the free public PeerJS server, so it works on a static Vercel site with no backend. The host's game is saved; guests play in the host's world.
- **Graphics:** Cinematic mode (bloom and colour grading) or Fast mode, in the Esc menu.
